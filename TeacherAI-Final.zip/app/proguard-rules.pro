# TeacherAI ProGuard Rules
-keepclassmembers class com.teacherai.app.AndroidBridge {
    public *;
}
-keep class com.teacherai.app.** { *; }
