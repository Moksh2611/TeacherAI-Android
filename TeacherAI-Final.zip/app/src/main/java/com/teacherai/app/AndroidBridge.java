package com.teacherai.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

public class AndroidBridge {
    private Activity activity;

    public AndroidBridge(Activity activity) {
        this.activity = activity;
    }

    @JavascriptInterface
    public void showToast(String message) {
        activity.runOnUiThread(() ->
            Toast.makeText(activity, message, Toast.LENGTH_SHORT).show()
        );
    }

    @JavascriptInterface
    public void copyToClipboard(String text) {
        ClipboardManager clipboard = (ClipboardManager)
            activity.getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("TeacherAI", text);
        clipboard.setPrimaryClip(clip);
        activity.runOnUiThread(() ->
            Toast.makeText(activity, "Copied to clipboard", Toast.LENGTH_SHORT).show()
        );
    }

    @JavascriptInterface
    public void openUrl(String url) {
        activity.runOnUiThread(() -> {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            activity.startActivity(intent);
        });
    }

    @JavascriptInterface
    public String getDeviceInfo() {
        return android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL +
               " (Android " + android.os.Build.VERSION.RELEASE + ")";
    }

    @JavascriptInterface
    public boolean isAndroid() {
        return true;
    }

    @JavascriptInterface
    public void vibrate(int milliseconds) {
        android.os.Vibrator v = (android.os.Vibrator)
            activity.getSystemService(Context.VIBRATOR_SERVICE);
        if (v != null) v.vibrate(milliseconds);
    }
}
