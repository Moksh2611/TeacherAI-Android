# 📱 TeacherAI — Android App

> **Ollama-powered offline teaching assistant — Android ke liye**

---

## 📦 Project Structure

```
TeacherAI-Android/
├── app/
│   ├── src/main/
│   │   ├── assets/
│   │   │   └── index.html          ← Pura app (HTML/JS/CSS)
│   │   ├── java/com/teacherai/app/
│   │   │   ├── MainActivity.java   ← WebView container
│   │   │   └── AndroidBridge.java  ← JS ↔ Android bridge
│   │   ├── res/
│   │   │   ├── values/             ← strings, colors, styles
│   │   │   ├── xml/                ← network security config
│   │   │   └── mipmap-*/           ← launcher icons
│   │   └── AndroidManifest.xml
│   └── build.gradle
├── build.gradle
├── settings.gradle
└── gradle.properties
```

---

## 🚀 APK Banane ke Steps (Android Studio)

### Step 1 — Android Studio Install Karein
- Download: https://developer.android.com/studio
- Install karein aur open karein

### Step 2 — Project Open Karein
1. Android Studio → **File → Open**
2. `TeacherAI-Android` folder select karein
3. Gradle sync hone tak wait karein (~2-3 minutes)

### Step 3 — Build APK
1. Menu: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
2. Wait karein...
3. `app/build/outputs/apk/debug/app-debug.apk` mil jaega

### Step 4 — Phone pe Install
```bash
# USB debugging enable karein (Settings → Developer Options → USB Debugging)
adb install app/build/outputs/apk/debug/app-debug.apk
```
Ya directly APK file phone pe copy karke install karein.

---

## 🔧 Ollama Setup (IMPORTANT)

TeacherAI ko Ollama chahiye. Android par 2 options hain:

### Option A — Same Device (rooted Android ya desktop app)
Ollama localhost par chal raha ho toh `http://localhost:11434` default kaam karega.

### Option B — PC se Connect (MOST COMMON)
Agar Ollama aapke **Windows/Mac/Linux PC** par chal raha hai:

1. PC par Ollama start karein:
   ```bash
   OLLAMA_HOST=0.0.0.0 ollama serve
   ```

2. App mein Settings → Ollama URL change karein:
   ```
   http://192.168.1.XXX:11434
   ```
   (Apna PC ka local IP daalein — WiFi settings mein milega)

3. PC aur Android **same WiFi** par hone chahiye

### Option C — Android Emulator (Testing)
Emulator mein PC ka IP hota hai `10.0.2.2`:
```
http://10.0.2.2:11434
```

---

## 📱 Features (Android Optimized)

| Feature | Status |
|---------|--------|
| PDF Upload | ✅ |
| Image OCR | ✅ |
| Text Paste | ✅ |
| Question Generator | ✅ |
| Worksheet Maker | ✅ |
| Exam Paper | ✅ |
| Lesson Plans | ✅ |
| Quiz Mode | ✅ |
| Offline Storage | ✅ (IndexedDB) |
| Export TXT/JSON | ✅ |
| Dark Theme | ✅ |
| Touch Optimized | ✅ |
| Hindi/Gujarati Support | ✅ |

---

## ⚙️ Technical Details

- **Min Android Version**: 5.0 (API 21)
- **Target SDK**: Android 14 (API 34)
- **Architecture**: WebView + Native Bridge
- **Storage**: IndexedDB (persistent)
- **Network**: HTTP cleartext allowed for localhost only

---

## 🐛 Common Issues

**"Ollama Offline" dikh raha hai:**
→ PC par `OLLAMA_HOST=0.0.0.0 ollama serve` chalao
→ Settings mein sahi IP daalo
→ Firewall mein port 11434 allow karein

**File upload kaam nahi kar raha:**
→ Android 13+ par storage permission dialog aayega — Allow karein

**App bahut slow hai:**
→ Settings mein model change karein (gemma3 ya phi3 try karein)

---

## 📞 Support

App ke baare mein sawaal ho toh Settings → About dekho.

---

*Made with ❤️ for Indian Teachers*
